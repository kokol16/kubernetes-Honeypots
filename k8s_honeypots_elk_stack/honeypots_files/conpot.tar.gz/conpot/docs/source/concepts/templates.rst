Templates
------------