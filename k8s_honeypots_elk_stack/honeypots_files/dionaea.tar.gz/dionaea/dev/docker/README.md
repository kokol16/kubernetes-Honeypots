You can find additional informations in ../../doc/source/development/setup.rst or in the generated documentation on https://dionaea.readthedocs.io/
