..
    This file is part of the dionaea honeypot

    SPDX-FileCopyrightText: 2011-2012 Markus Koetter
    SPDX-FileCopyrightText: 2015-2017 PhiBo (DinoTools)

    SPDX-License-Identifier: GPL-2.0-or-later

curl
====

The curl module is used to transfer files from and to servers, it is
used to download files via http as well as submitting files to 3rd parties.
