..
    This file is part of the dionaea honeypot

    SPDX-FileCopyrightText: 2016 PhiBo (DinoTools)

    SPDX-License-Identifier: GPL-2.0-or-later

Memache
=======

Dionaea can emulate a very basic memcached server.

Configure
---------

Example config
--------------

.. literalinclude:: ../../../conf/services/memcache.yaml
    :language: yaml
    :caption: services/memcache.yaml
