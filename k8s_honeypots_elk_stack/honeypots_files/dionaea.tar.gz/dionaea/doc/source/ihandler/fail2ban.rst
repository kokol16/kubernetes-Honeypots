..
    This file is part of the dionaea honeypot

    SPDX-FileCopyrightText: 2011-2012 Markus Koetter
    SPDX-FileCopyrightText: 2015-2017 PhiBo (DinoTools)

    SPDX-License-Identifier: GPL-2.0-or-later

fail2ban
========

Example config
--------------

.. literalinclude:: ../../../conf/ihandlers/fail2ban.yaml.in
   :language: yaml
   :caption: ihandlers/fail2ban.yaml
