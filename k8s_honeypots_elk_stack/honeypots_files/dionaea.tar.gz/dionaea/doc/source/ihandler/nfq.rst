..
    This file is part of the dionaea honeypot

    SPDX-FileCopyrightText: 2011-2012 Markus Koetter
    SPDX-FileCopyrightText: 2015-2017 PhiBo (DinoTools)

    SPDX-License-Identifier: GPL-2.0-or-later

nfq
===

Example config
--------------

.. literalinclude:: ../../../conf/ihandlers/nfq.yaml
   :language: yaml
   :caption: ihandlers/nfq.yaml
