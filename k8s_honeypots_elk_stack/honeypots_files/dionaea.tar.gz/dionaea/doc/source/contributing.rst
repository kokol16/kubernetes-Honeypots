..
    This file is part of the dionaea honeypot

    SPDX-FileCopyrightText: 2015-2020 PhiBo (DinoTools)

    SPDX-License-Identifier: GPL-2.0-or-later

.. include:: ../../CONTRIBUTING.rst
.. include:: licensing.rst
