..
    This file is part of the dionaea honeypot

    SPDX-FileCopyrightText: 2011-2012 Markus Koetter
    SPDX-FileCopyrightText: 2015-2017 PhiBo (DinoTools)

    SPDX-License-Identifier: GPL-2.0-or-later

Submit
======

Once dionaea got a copy of the worm attacking her, we may want to store
the file locally for further analysis, or submit the file to some 3rd
party for further analysis.

dionaea can http/POST the file to several services like CWSandbox,
Norman Sandbox or VirusTotal.
