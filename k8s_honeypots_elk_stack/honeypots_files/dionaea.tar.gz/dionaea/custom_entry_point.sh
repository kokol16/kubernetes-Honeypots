#!/bin/sh
#ENTRYPOINT ["/usr/local/sbin/entrypoint.sh"]
echo "lala1"

/usr/local/sbin/entrypoint.sh &
echo "lala2"
log= python3 /opt/dionaeaSqliteToJson.py
echo $log
